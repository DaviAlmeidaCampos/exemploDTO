package com.JoaoGustavo.DTO.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.JoaoGustavo.DTO.entities.entityDTO;

public interface repositoryDTO extends JpaRepository<entityDTO, Long>{

}
